Project 1
Xianzhi Luo B00814692
- Run
	Extract the project1.tar.gz file and open the project1 folder
	Open in terminal and type command python project1 input.txt
	You will get an output file
